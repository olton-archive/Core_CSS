# Welcome
Core_CSS - is a free and open source mobile HTML framework to develop hybrid mobile apps or web apps in Material Design Style.
The main approach of the Core_CSS is to give you an opportunity to create Mobile apps with HTML, CSS and JavaScript easily and clear.
Core_CSS is completely <strong>free</strong> and <strong>open-source</strong> (MIT Licensed).

## Site
http://coreui.org.ua

## Repo
https://github.com/olton/Core_CSS