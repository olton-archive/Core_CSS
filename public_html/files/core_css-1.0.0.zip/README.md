# CoreCSS
Universal CSS Framework for Phonegap
